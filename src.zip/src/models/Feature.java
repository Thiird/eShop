package models;

public enum Feature
{
	GLUTEN_FREE, MILK_FREE, BIO, MADE_IN_ITALY
}