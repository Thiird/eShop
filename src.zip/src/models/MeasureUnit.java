package models;

public enum MeasureUnit
{
	g, Kg, L
}