package models;

public enum State
{
	CONFIRMED, PREPARING, DELIVERED,
}