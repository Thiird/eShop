package models;

public enum Type
{
	ALL, PIZZA, CAKE, MEAT, BREAD, BISCUIT, FRUIT, VEGETABLE, OTHERS;
}