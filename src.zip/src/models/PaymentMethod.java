package models;

public enum PaymentMethod
{
	CREDIT_CARD, PAYPAL, ON_DELIVERY
}