package models;

public enum Role
{
	MANAGER
}